
import streamlit as st
import speech_recognition as sr
from gtts import gTTS
import os

st.title("Speech-to-Text & Text-to-Speech")

choice = st.radio("Select Mode", ["Speech to Text", "Text to Speech"])

if choice == "Speech to Text":
    st.subheader("Upload a WAV file")
    audio_file = st.file_uploader("Choose an audio file", type=["wav"])
    if audio_file is not None:
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_file) as source:
            audio = recognizer.record(source)
            try:
                text = recognizer.recognize_google(audio)
                st.success("Recognized Text:")
                st.write(text)
            except sr.UnknownValueError:
                st.error("Could not understand the audio.")
            except sr.RequestError as e:
                st.error(f"API error: {e}")

elif choice == "Text to Speech":
    st.subheader("Enter text below")
    text_input = st.text_input("Text:")
    if st.button("Convert to Speech"):
        tts = gTTS(text_input)
        tts.save("output.mp3")
        audio_file = open("output.mp3", "rb")
        audio_bytes = audio_file.read()
        st.audio(audio_bytes, format="audio/mp3")
